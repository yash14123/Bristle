from django.conf.urls import include, url
from django.contrib import admin
from project import views as app_views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
    # Examples:
    # url(r'^$', 'bristle.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', app_views.index, name='index'),
    url(r'^create/', app_views.create, name='create'),
    url(r'^signup/', app_views.signup, name='signup'),
    url(r'^dashboard/', app_views.dashboard, name='dashboard'),
    url(r'^myprojects/', app_views.myprojects, name='myprojects'),
    url(r'^allprojects/', app_views.allprojects, name='allprojects'),
    url(r'^submitproject/', app_views.submitproject, name='submitproject'),
    url(r'^projectview/', app_views.projectview, name='projectview'),
    url(r'^clientprojectview/(?P<projectid>[0-9]+)/', app_views.clientprojectview, name='clientprojectview'),
    url(r'^myresults/', app_views.myresults, name='myresults'),
    url(r'^login/', auth_views.login, {'template_name': 'project/login.html'}, name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': 'login'}, name='logout'),

]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)