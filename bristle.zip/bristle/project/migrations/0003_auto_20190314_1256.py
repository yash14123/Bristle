# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('project', '0002_auto_20190314_1255'),
    ]

    operations = [
        migrations.AlterField(
            model_name='project',
            name='color_palette_1',
            field=models.CharField(default=b'', max_length=60, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='color_palette_2',
            field=models.CharField(default=b'', max_length=60, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='color_palette_3',
            field=models.CharField(default=b'', max_length=60, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='consultant_username',
            field=models.CharField(max_length=60, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='light_in_room',
            field=models.CharField(max_length=254, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='photo_upload_1',
            field=models.ImageField(upload_to=b'', blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='photo_upload_2',
            field=models.ImageField(upload_to=b'', blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='photo_upload_3',
            field=models.ImageField(upload_to=b'', blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='room_feel',
            field=models.CharField(default=b'', max_length=60, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='room_size',
            field=models.CharField(max_length=120, blank=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='type_of_room',
            field=models.CharField(max_length=120, blank=True),
        ),
    ]
