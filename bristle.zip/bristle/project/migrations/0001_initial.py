# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Project',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('project_name', models.CharField(max_length=60)),
                ('customer_username', models.CharField(max_length=60)),
                ('status', models.BooleanField()),
                ('consultant_username', models.CharField(max_length=60)),
                ('date_of_addition', models.DateField()),
                ('type_of_room', models.CharField(max_length=120)),
                ('room_size', models.CharField(max_length=120)),
                ('light_in_room', models.CharField(max_length=254)),
                ('room_feel', models.CharField(default=b'', max_length=60)),
                ('color_palette_1', models.CharField(default=b'', max_length=60)),
                ('color_palette_2', models.CharField(default=b'', max_length=60)),
                ('color_palette_3', models.CharField(default=b'', max_length=60)),
                ('color_palette_4', models.CharField(default=b'', max_length=60)),
                ('color_palette_5', models.CharField(default=b'', max_length=60)),
                ('photo_upload_1', models.ImageField(upload_to=b'')),
                ('photo_upload_2', models.ImageField(upload_to=b'')),
                ('photo_upload_3', models.ImageField(upload_to=b'')),
                ('photo_upload_4', models.ImageField(upload_to=b'')),
                ('photo_upload_5', models.ImageField(upload_to=b'')),
            ],
        ),
    ]
