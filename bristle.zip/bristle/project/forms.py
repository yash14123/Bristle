from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class SignupForm(UserCreationForm):
    firstname = forms.CharField(required=True)
    lastname = forms.CharField(required=True)
    class Meta:
        
        model = User
        fields = ('username', 'firstname',  'lastname', 'password1', 'password2',
         )