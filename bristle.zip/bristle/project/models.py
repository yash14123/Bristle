from django.db import models
import datetime
# Create your models here.
class Project(models.Model):
    project_name = models.CharField(max_length=60)
    customer_username = models.CharField(max_length=60)
    status = models.BooleanField()
    consultant_username = models.CharField(max_length=60,blank=True)
    date_of_addition = models.DateField(null=True,default=datetime.date.today)
    type_of_room = models.CharField(max_length=120,blank=True)
    room_size = models.CharField(max_length=120,blank=True)
    light_in_room = models.CharField(max_length=254,blank=True)
    room_feel = models.CharField(max_length=60,default='',blank=True)
    color_palette_1 = models.CharField(max_length=60,default='',blank=True)
    color_palette_2 = models.CharField(max_length=60,default='',blank=True)
    color_palette_3 = models.CharField(max_length=60,default='',blank=True)
    photo_upload_1 = models.ImageField(blank=True)
    photo_upload_2 = models.ImageField(blank=True)
    photo_upload_3 = models.ImageField(blank=True)
    project_description = models.CharField(max_length=6000,default='',blank=True)
    


    def __str__(self):
        return self.project_name