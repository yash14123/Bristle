from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from .forms import SignupForm
from project.models import Project 

# Create your views here.
def index(request):
	return render(request,'project/index.html')

def create(request):
	return render(request,'project/newproject.html')


def signup(request):
	if request.method=='POST':
		form = SignupForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('login')
		else:
			return render(request, 'project/register.html',{'form':form})
	else:
		form = SignupForm()
		return render(request, 'project/register.html',{'form':form})

@login_required
def dashboard(request):
	projects = Project.objects.all().filter(customer_username=request.user.username)
	return render(request,'project/dashboard.html',{'projects':projects})

def submitproject(request):
	if request.method == "POST":
		
		q1 = request.POST.get("q1")
		q2 = request.FILES.get('q2',False)
		q3 = request.POST.get("q3")
		q4 = request.POST.get("q4")
		q5 = request.POST.get("q5")
		q6 = request.POST.get("q6")
		q7 = request.POST.get("q7")
		q8 = request.POST.get("q8")

		Project.objects.create(
			project_name = q8,
			customer_username = request.user.username,
			status = False,
			type_of_room = q1,
			room_size = q3,
			light_in_room = q4,
			room_feel = q5,
			color_palette_1 = q6,
			photo_upload_1 = q2,
			project_description = q7
			)
		

		
		print q1,q2,q3,q4,q5,q6,q7,q8

	return dashboard(request)

@login_required
def myprojects(request):
	return render(request,'project/index.html')

@login_required
def allprojects(request):
	return render(request,'project/allprojects.html')

@login_required
def projectview(request):
	return render(request,'project/projectview.html')

@login_required
def clientprojectview(request,projectid):
	project = Project.objects.get(pk=projectid)
	return render(request,'project/clientprojectview.html',{'project':project})

@login_required
def myresults(request):
	return render(request,'project/index.html')