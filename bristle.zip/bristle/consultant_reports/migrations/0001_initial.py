# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='ConsultantReport',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('project_name', models.CharField(max_length=60)),
                ('project_id', models.IntegerField()),
                ('customer_username', models.CharField(max_length=60)),
                ('consultant_username', models.CharField(max_length=60)),
                ('date_of_addition', models.DateField()),
                ('theme_name', models.CharField(max_length=60)),
                ('theme_inspiration', models.CharField(max_length=60)),
                ('color_chosen_1', models.CharField(default=b'', max_length=60)),
                ('color_chosen_2', models.CharField(default=b'', max_length=60)),
                ('color_chosen_3', models.CharField(default=b'', max_length=60)),
                ('color_chosen_4', models.CharField(default=b'', max_length=60)),
                ('color_chosen_5', models.CharField(default=b'', max_length=60)),
                ('inspiration_photo_upload_1', models.ImageField(upload_to=b'')),
                ('inspiration_photo_upload_2', models.ImageField(upload_to=b'')),
                ('inspiration_photo_upload_3', models.ImageField(upload_to=b'')),
                ('inspiration_photo_upload_4', models.ImageField(upload_to=b'')),
                ('inspiration_photo_upload_5', models.ImageField(upload_to=b'')),
                ('room_visualization', models.ImageField(upload_to=b'')),
            ],
        ),
    ]
