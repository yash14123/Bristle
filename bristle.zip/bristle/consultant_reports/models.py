from django.db import models

# Create your models here.
class ConsultantReport(models.Model):
    project_name = models.CharField(max_length=60)
    project_id = models.IntegerField()
    customer_username = models.CharField(max_length=60)
    consultant_username = models.CharField(max_length=60)
    date_of_addition = models.DateField()
    theme_name = models.CharField(max_length=60)
    theme_inspiration = models.CharField(max_length=60)
    color_chosen_1 = models.CharField(max_length=60,default='')
    color_chosen_2 = models.CharField(max_length=60,default='')
    color_chosen_3 = models.CharField(max_length=60,default='')
    color_chosen_4 = models.CharField(max_length=60,default='')
    color_chosen_5 = models.CharField(max_length=60,default='')
    inspiration_photo_upload_1 = models.ImageField()
    inspiration_photo_upload_2 = models.ImageField()
    inspiration_photo_upload_3 = models.ImageField()
    inspiration_photo_upload_4 = models.ImageField()
    inspiration_photo_upload_5 = models.ImageField()
    room_visualization = models.ImageField()


    def __str__(self):
        return self.project_name